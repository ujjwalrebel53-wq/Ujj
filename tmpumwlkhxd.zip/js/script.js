document.addEventListener('DOMContentLoaded', async () => {
    const loadingScreen = document.getElementById('loading-screen');
    const mainContent = document.getElementById('main-content');
    const searchInput = document.querySelector('.search-bar input');
    const tablesContainer = document.querySelectorAll('.table-container');
    const modal = document.getElementById('apiResponseModal');
    
    const pendingRequests = new Map();
    
    const modalRefs = {
        label: document.getElementById('apiResponseModalLabel'),
        desc: document.getElementById('apiResponseModalDesc'),
        content: document.getElementById('apiResponseContent'),
        endpoint: document.getElementById('apiEndpoint'),
        queryInputContainer: document.getElementById('apiQueryInputContainer'),
        submitBtn: document.getElementById('submitQueryBtn'),
        closeBtn: document.querySelector('.modal-close'),
        copyBtn: document.getElementById('copyEndpointBtn')
    };

    modalRefs.currentImageUrl = null;
    let lastTriggerButton = null;
    let currentEndpointData = null;

    const noResults = document.createElement('div');
    noResults.id = 'no-results';
    noResults.style.display = 'none';
    noResults.textContent = 'No results found';
    noResults.style.cssText = `
        text-align: center;
        padding: 40px;
        color: var(--text-secondary);
        font-size: 1.1rem;
        display: none;
    `;
    document.body.appendChild(noResults);

    if (typeof hljs !== 'undefined') {
        hljs.configure({
            cssSelector: 'pre code',
            ignoreUnescapedHTML: true
        });
    }

    function initSideMenu() {
        const hamburgerBtn = document.getElementById('hamburgerBtn');
        const sideMenu = document.getElementById('sideMenu');
        const sideMenuOverlay = document.getElementById('sideMenuOverlay');
        const closeMenuBtn = document.getElementById('closeMenuBtn');
        const sideSearchInput = document.getElementById('sideSearchInput');
        const sideMenuLinks = document.querySelectorAll('.side-menu-nav a');

        if (!hamburgerBtn || !sideMenu || !sideMenuOverlay) return;

        function openSideMenu() {
            sideMenu.classList.add('open');
            sideMenuOverlay.classList.add('active');
            document.body.style.overflow = 'hidden';
        }

        function closeSideMenu() {
            sideMenu.classList.remove('open');
            sideMenuOverlay.classList.remove('active');
            document.body.style.overflow = '';
        }

        hamburgerBtn.addEventListener('click', openSideMenu);
        if (closeMenuBtn) closeMenuBtn.addEventListener('click', closeSideMenu);
        sideMenuOverlay.addEventListener('click', closeSideMenu);

        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && sideMenu.classList.contains('open')) {
                closeSideMenu();
            }
        });

        if (sideSearchInput) {
            sideSearchInput.addEventListener('input', (e) => {
                const searchTerm = e.target.value.toLowerCase();
                sideMenuLinks.forEach(link => {
                    const text = link.textContent.toLowerCase();
                    link.style.display = text.includes(searchTerm) ? 'flex' : 'none';
                });
            });
        }

        sideMenuLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const category = link.getAttribute('data-category');
                if (category) {
                    const targetTbody = document.getElementById(`routes-table-body-${category}`);
                    if (targetTbody) {
                        const tableContainer = targetTbody.closest('.table-container');
                        if (tableContainer) {
                            tableContainer.scrollIntoView({ behavior: 'smooth', block: 'start' });
                            tableContainer.style.transition = 'all 0.3s';
                            tableContainer.style.borderColor = 'var(--accent-color)';
                            tableContainer.style.transform = 'scale(1.01)';
                            setTimeout(() => {
                                tableContainer.style.transform = '';
                                setTimeout(() => {
                                    tableContainer.style.borderColor = '';
                                }, 500);
                            }, 300);
                        }
                        closeSideMenu();
                    }
                } else {
                    const href = link.getAttribute('href');
                    if (href && href !== '#') {
                        window.location.href = href;
                    }
                }
            });
        });
    }

    async function loadEndpoints() {
        try {
            const response = await fetch('/allEnds');
            if (!response.ok) {
                throw new Error(`Failed to load endpoints: ${response.status}`);
            }
            const endpoints = await response.json();
            populateTables(endpoints.data);
            loadingScreen.style.display = 'none';
            mainContent.style.display = 'block';
            initSideMenu();
            
            if (typeof hljs !== 'undefined') {
                hljs.highlightAll();
            }
        } catch (error) {
            console.error('Error loading endpoints:', error);
            loadingScreen.querySelector('.loading-text').textContent = 'Failed to load endpoints';
            setTimeout(() => {
                loadingScreen.style.display = 'none';
                mainContent.style.display = 'block';
                initSideMenu();
            }, 2000);
        }
    }

    function populateTables(endpoints) {
        document.querySelectorAll('tbody').forEach(tbody => {
            tbody.innerHTML = '';
        });

        const categoryMap = {
            'ai': 'routes-table-body-ai',
            'downloader': 'routes-table-body-downloaders',
            'search': 'routes-table-body-search',
            'anime': 'routes-table-body-anime',
            'stalk': 'routes-table-body-stalk',
            'tools': 'routes-table-body-tools',
            'nsfw': 'routes-table-body-nsfw',
            'tools-extra': 'routes-table-body-tools-extra',
            'random': 'routes-table-body-random',
            'images': 'routes-table-body-images'
        };

        Object.keys(endpoints).forEach(category => {
            const tableId = categoryMap[category];
            if (!tableId) return;
            
            const tbody = document.getElementById(tableId);
            if (!tbody) return;

            endpoints[category].forEach(endpoint => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td> ${endpoint.name}</td>
                    <td>${endpoint.method || 'GET'}</td>
                    <td><span class="badge"><i class="fa-regular fa-circle-check"></i></span></td>
                    <td><button class="icon-btn try-btn" 
                        data-api-path="${endpoint.path}" 
                        data-api-name="${endpoint.name}" 
                        data-api-desc="${endpoint.description || endpoint.name}"
                        data-api-method="${endpoint.method || 'GET'}"
                        data-api-params='${JSON.stringify(endpoint.params || {})}'
                        ${endpoint.nsfw ? 'data-nsfw="true"' : ''}>
                        <i class="fa-solid fa-play"></i>
                    </button></td>
                `;
                tbody.appendChild(row);
            });
        });

        attachEventListeners();
    }

    function attachEventListeners() {
        document.querySelectorAll('.try-btn').forEach(button => {
            const apiPath = button.getAttribute('data-api-path');
            const apiName = button.getAttribute('data-api-name');
            const apiDesc = button.getAttribute('data-api-desc');
            const apiMethod = button.getAttribute('data-api-method');
            let apiParams = {};
            try {
                apiParams = JSON.parse(button.getAttribute('data-api-params') || '{}');
            } catch (e) {
                console.error('Error parsing params for', apiName, e);
            }
            
            const buttonKey = `${apiPath}-${apiMethod}`;
            
            button.addEventListener('click', function(event) {
                if (pendingRequests.has(buttonKey)) {
                    console.log('Request already in progress, ignoring...');
                    return;
                }
                
                button.disabled = true;
                button.classList.add('loading');
                
                openModalAndSetup(apiPath, apiName, apiDesc, apiMethod, apiParams, event, button);
                
                setTimeout(() => {
                    if (!pendingRequests.has(buttonKey)) {
                        button.disabled = false;
                        button.classList.remove('loading');
                    }
                }, 1500);
            });
            
            button.addEventListener('dblclick', (e) => {
                e.preventDefault();
                e.stopPropagation();
            });
            
            button.setAttribute('title', 'Test this API endpoint');
            button.setAttribute('aria-label', 'Test API endpoint');
        });
    }

    async function openModalAndSetup(apiPath, apiName, apiDesc, apiMethod, apiParams, event, button) {
        const buttonKey = `${apiPath}-${apiMethod}`;
        
        try {
            lastTriggerButton = button;
            currentEndpointData = {
                path: apiPath,
                name: apiName,
                desc: apiDesc,
                method: apiMethod,
                params: apiParams
            };
            
            const cleanPath = apiPath.split('?')[0];
            
            modalRefs.label.textContent = apiName;
            modalRefs.desc.textContent = apiDesc;
            
            let endpointUrl = window.location.origin + cleanPath;
            if (Object.keys(apiParams).length > 0) {
                const urlParams = new URLSearchParams();
                Object.entries(apiParams).forEach(([key, value]) => {
                    if (value) {
                        urlParams.set(key, value);
                    }
                });
                const paramString = urlParams.toString();
                if (paramString) {
                    endpointUrl += '?' + paramString;
                }
            }
            modalRefs.endpoint.textContent = endpointUrl;
            modalRefs.endpoint.classList.remove('d-none');
            modalRefs.copyBtn.classList.remove('d-none');
            modalRefs.content.classList.add('d-none');
            modalRefs.queryInputContainer.innerHTML = '';

            const hasParams = Object.keys(apiParams).length > 0 || apiMethod === 'POST';
            
            if (hasParams) {
                if (Object.keys(apiParams).length > 0) {
                    const paramsTitle = document.createElement('h6');
                    paramsTitle.textContent = 'Parameters';
                    paramsTitle.style.cssText = `
                        color: var(--text-primary);
                        margin: 0 0 15px 0;
                        font-size: 1rem;
                        font-weight: 600;
                    `;
                    modalRefs.queryInputContainer.appendChild(paramsTitle);
                    
                    Object.entries(apiParams).forEach(([key, value]) => {
                        createParamInput(key, value, apiMethod);
                    });
                }
                
                if (apiMethod === 'POST') {
                    const postParamsTitle = document.createElement('h6');
                    postParamsTitle.textContent = 'Request Body (JSON)';
                    postParamsTitle.style.cssText = `
                        color: var(--text-primary);
                        margin: 15px 0 10px 0;
                        font-size: 1rem;
                    `;
                    modalRefs.queryInputContainer.appendChild(postParamsTitle);

                    const jsonTextarea = document.createElement('textarea');
                    jsonTextarea.id = 'postBodyJson';
                    jsonTextarea.placeholder = 'Enter JSON data for POST request...\nExample: {"key": "value", "number": 123}';
                    jsonTextarea.style.cssText = `
                        width: 100%;
                        height: 120px;
                        padding: 10px;
                        border: 1px solid var(--border-color);
                        border-radius: var(--border-radius);
                        background: var(--header-bg);
                        color: var(--text-primary);
                        font-family: 'Courier New', monospace;
                        font-size: 0.9rem;
                        resize: vertical;
                    `;
                    jsonTextarea.addEventListener('focus', function() {
                        this.style.borderColor = 'var(--accent-color)';
                        this.style.outline = 'none';
                    });
                    jsonTextarea.addEventListener('blur', function() {
                        this.style.borderColor = 'var(--border-color)';
                    });
                    modalRefs.queryInputContainer.appendChild(jsonTextarea);
                }

                modalRefs.submitBtn.classList.remove('d-none');
            } else {
                modalRefs.submitBtn.classList.add('d-none');
            }

            showModal();

            if (Object.keys(apiParams).length === 0 && apiMethod === 'GET') {
                pendingRequests.set(buttonKey, true);
                await fetchApiResponse(cleanPath, apiMethod);
                pendingRequests.delete(buttonKey);
            }

            modalRefs.copyBtn.onclick = async function() {
                this.classList.add('btn-loading');
                try {
                    const endpointUrl = modalRefs.endpoint.textContent;
                    await navigator.clipboard.writeText(endpointUrl);
                    this.classList.remove('btn-loading');
                    this.classList.add('copied');
                    this.textContent = 'Copied!';
                    this.setAttribute('aria-label', 'API copied to clipboard');
                    setTimeout(() => {
                        this.classList.remove('copied');
                        this.textContent = 'Copy API';
                        this.setAttribute('aria-label', 'Copy API endpoint URL');
                    }, 2000);
                } catch (err) {
                    console.error('Failed to copy: ', err);
                    this.classList.remove('btn-loading');
                }
            };

            let submitDebounceTimeout;
            modalRefs.submitBtn.onclick = async function() {
                if (this.disabled) return;
                
                clearTimeout(submitDebounceTimeout);
                submitDebounceTimeout = setTimeout(async () => {
                    this.classList.add('btn-loading');
                    this.disabled = true;

                    const params = {};
                    const inputs = modalRefs.queryInputContainer.querySelectorAll('input[data-param], textarea[data-param]');
                    inputs.forEach(input => {
                        if (input.value.trim()) {
                            params[input.dataset.param] = input.value.trim();
                        }
                    });

                    let requestUrl = cleanPath;
                    
                    if (apiMethod === 'GET' && Object.keys(params).length > 0) {
                        const urlParams = new URLSearchParams();
                        Object.entries(params).forEach(([key, value]) => {
                            urlParams.set(key, value);
                        });
                        requestUrl += '?' + urlParams.toString();
                    }

                    let requestOptions = {
                        method: apiMethod
                    };

                    if (apiMethod === 'POST') {
                        const jsonTextarea = document.getElementById('postBodyJson');
                        if (jsonTextarea && jsonTextarea.value.trim()) {
                            try {
                                const jsonData = JSON.parse(jsonTextarea.value.trim());
                                requestOptions.headers = {
                                    'Content-Type': 'application/json'
                                };
                                requestOptions.body = JSON.stringify(jsonData);
                            } catch (error) {
                                alert('Invalid JSON format! Please check your input.');
                                this.classList.remove('btn-loading');
                                this.disabled = false;
                                return;
                            }
                        } else if (Object.keys(params).length > 0) {
                            const formData = new URLSearchParams();
                            Object.entries(params).forEach(([key, value]) => {
                                formData.append(key, value);
                            });
                            requestOptions.headers = {
                                'Content-Type': 'application/x-www-form-urlencoded'
                            };
                            requestOptions.body = formData.toString();
                        }
                        
                        const displayUrl = window.location.origin + cleanPath;
                        modalRefs.endpoint.textContent = displayUrl;
                    } else {
                        const displayUrl = window.location.origin + requestUrl;
                        modalRefs.endpoint.textContent = displayUrl;
                    }

                    pendingRequests.set(buttonKey, true);
                    await fetchApiResponse(requestUrl, apiMethod, requestOptions);
                    pendingRequests.delete(buttonKey);
                    
                    this.classList.remove('btn-loading');
                    this.disabled = false;
                }, 500);
            };
            
            const updateEndpointDisplay = () => {
                if (apiMethod === 'GET') {
                    const params = {};
                    const inputs = modalRefs.queryInputContainer.querySelectorAll('input[data-param], textarea[data-param]');
                    inputs.forEach(input => {
                        if (input.value.trim()) {
                            params[input.dataset.param] = input.value.trim();
                        }
                    });
                    
                    let endpointUrl = window.location.origin + cleanPath;
                    if (Object.keys(params).length > 0) {
                        const urlParams = new URLSearchParams();
                        Object.entries(params).forEach(([key, value]) => {
                            urlParams.set(key, value);
                        });
                        endpointUrl += '?' + urlParams.toString();
                    }
                    modalRefs.endpoint.textContent = endpointUrl;
                }
            };
            
            const addInputListeners = () => {
                const inputs = modalRefs.queryInputContainer.querySelectorAll('input[data-param], textarea[data-param]');
                inputs.forEach(input => {
                    input.removeEventListener('input', updateEndpointDisplay);
                    input.addEventListener('input', updateEndpointDisplay);
                });
            };
            
            addInputListeners();
            const observer = new MutationObserver((mutations) => {
                mutations.forEach((mutation) => {
                    if (mutation.type === 'childList') {
                        addInputListeners();
                    }
                });
            });
            observer.observe(modalRefs.queryInputContainer, { childList: true, subtree: true });
            
            modalRefs._observer = observer;
            
        } finally {
            setTimeout(() => {
                if (button && !pendingRequests.has(buttonKey)) {
                    button.disabled = false;
                    button.classList.remove('loading');
                }
            }, 100);
        }
    }

    function createParamInput(key, defaultValue, apiMethod) {
        const paramContainer = document.createElement('div');
        paramContainer.className = 'param-container';
        paramContainer.style.cssText = `
            margin-bottom: 15px;
        `;
        
        const label = document.createElement('label');
        label.textContent = key;
        label.style.cssText = `
            color: var(--text-secondary);
            font-size: 0.9rem;
            margin-bottom: 5px;
            display: block;
            font-weight: 500;
        `;

        const isUrlParam = ['url', 'image', 'img', 'link', 'src'].includes(key.toLowerCase());
        
        if (isUrlParam) {
            const textarea = document.createElement('textarea');
            textarea.value = defaultValue || '';
            textarea.dataset.param = key;
            textarea.placeholder = `Enter ${key} (URL)`;
            textarea.style.cssText = `
                width: 100%;
                height: 80px;
                padding: 10px;
                border: 1px solid var(--border-color);
                border-radius: var(--border-radius);
                background: var(--header-bg);
                color: var(--text-primary);
                font-size: 0.9rem;
                resize: vertical;
                font-family: inherit;
            `;

            textarea.addEventListener('focus', function() {
                this.style.borderColor = 'var(--accent-color)';
                this.style.outline = 'none';
            });

            textarea.addEventListener('blur', function() {
                this.style.borderColor = 'var(--border-color)';
            });

            paramContainer.appendChild(label);
            paramContainer.appendChild(textarea);
        } else {
            const input = document.createElement('input');
            input.type = 'text';
            input.value = defaultValue || '';
            input.dataset.param = key;
            input.placeholder = `Enter ${key}`;
            input.style.cssText = `
                width: 100%;
                padding: 10px;
                border: 1px solid var(--border-color);
                border-radius: var(--border-radius);
                background: var(--header-bg);
                color: var(--text-primary);
                font-size: 0.9rem;
            `;

            input.addEventListener('focus', function() {
                this.style.borderColor = 'var(--accent-color)';
                this.style.outline = 'none';
            });

            input.addEventListener('blur', function() {
                this.style.borderColor = 'var(--border-color)';
            });

            paramContainer.appendChild(label);
            paramContainer.appendChild(input);
        }

        modalRefs.queryInputContainer.appendChild(paramContainer);
    }

    async function fetchApiResponse(fullPath, method = 'GET', options = {}) {
        modalRefs.content.classList.add('d-none');
        modalRefs.content.innerHTML = '';

        try {
            const fetchOptions = {
                method: method,
                ...options
            };

            const response = await fetch(fullPath, fetchOptions);
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const contentType = response.headers.get('content-type');
            
            if (contentType && contentType.includes('application/json')) {
                const data = await response.json();
                displayApiResponse(data, true);
            } else if (contentType && contentType.includes('image/')) {
                const blob = await response.blob();
                displayApiResponse(blob, false);
            } else {
                const text = await response.text();
                displayApiResponse(text, false);
            }
        } catch (error) {
            console.error('API Error:', error);
            modalRefs.content.classList.remove('d-none');
            modalRefs.content.className = 'error';
            modalRefs.content.textContent = 'Error: ' + error.message;
        }
    }

    function displayApiResponse(response, isJson = true) {
        modalRefs.content.classList.remove('d-none');
        try {
            if (isJson) {
                const formattedJson = JSON.stringify(response, null, 2);
                modalRefs.content.innerHTML = `<pre><code class="language-json">${escapeHtml(formattedJson)}</code></pre>`;
                if (typeof hljs !== 'undefined') {
                    const codeBlock = modalRefs.content.querySelector('code');
                    if (codeBlock) {
                        hljs.highlightElement(codeBlock);
                    }
                }
            } else if (typeof response === 'string') {
                if (response.includes('<') && response.includes('>')) {
                    modalRefs.content.innerHTML = `<pre><code class="language-html">${escapeHtml(response)}</code></pre>`;
                    if (typeof hljs !== 'undefined') {
                        const codeBlock = modalRefs.content.querySelector('code');
                        if (codeBlock) {
                            hljs.highlightElement(codeBlock);
                        }
                    }
                } else {
                    modalRefs.content.innerHTML = `<pre><code class="language-plaintext">${escapeHtml(response)}</code></pre>`;
                    if (typeof hljs !== 'undefined') {
                        const codeBlock = modalRefs.content.querySelector('code');
                        if (codeBlock) {
                            hljs.highlightElement(codeBlock);
                        }
                    }
                }
            } else if (response instanceof Blob) {
                if (response.type.startsWith('image/')) {
                    const imgUrl = URL.createObjectURL(response);
                    modalRefs.currentImageUrl = imgUrl;
                    modalRefs.content.innerHTML = `<img src="${imgUrl}" alt="API Response Image" style="max-width: 100%; height: auto; border-radius: 6px;">`;
                    const img = modalRefs.content.querySelector('img');
                    img.onload = () => URL.revokeObjectURL(imgUrl);
                } else {
                    modalRefs.content.textContent = 'Binary data received';
                }
            } else {
                const formattedJson = JSON.stringify(response, null, 2);
                modalRefs.content.innerHTML = `<pre><code class="language-json">${escapeHtml(formattedJson)}</code></pre>`;
                if (typeof hljs !== 'undefined') {
                    const codeBlock = modalRefs.content.querySelector('code');
                    if (codeBlock) {
                        hljs.highlightElement(codeBlock);
                    }
                }
            }
        } catch (error) {
            console.error('Error displaying response:', error);
            modalRefs.content.className = 'error';
            modalRefs.content.textContent = 'Error displaying response: ' + error.message;
        }
    }

    function escapeHtml(unsafe) {
        return unsafe
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }

    function showModal() {
        modal.style.display = 'flex';
        modal.setAttribute('aria-hidden', 'false');
        modalRefs.closeBtn.focus();
        setTimeout(() => {
            if (typeof hljs !== 'undefined') {
                const codeBlocks = modalRefs.content.querySelectorAll('pre code');
                codeBlocks.forEach(block => {
                    hljs.highlightElement(block);
                });
            }
        }, 100);
    }

    function hideModal() {
        if (lastTriggerButton && lastTriggerButton.focus) {
            setTimeout(() => lastTriggerButton.focus(), 100);
        } else if (searchInput) {
            setTimeout(() => searchInput.focus(), 100);
        }
        modal.style.display = 'none';
        modal.setAttribute('aria-hidden', 'true');
        modalRefs.queryInputContainer.innerHTML = '';
        modalRefs.submitBtn.classList.add('d-none');
        modalRefs.content.classList.add('d-none');
        modalRefs.endpoint.classList.add('d-none');
        modalRefs.copyBtn.classList.add('d-none');
        modalRefs.copyBtn.classList.remove('copied');
        modalRefs.copyBtn.textContent = 'Copy API';
        modalRefs.content.classList.remove('error');
        
        if (modalRefs._observer) {
            modalRefs._observer.disconnect();
            delete modalRefs._observer;
        }
        
        if (modalRefs.currentImageUrl) {
            URL.revokeObjectURL(modalRefs.currentImageUrl);
            modalRefs.currentImageUrl = null;
        }
        
        lastTriggerButton = null;
        currentEndpointData = null;
    }

    loadEndpoints();

    let debounceTimeout;
    if (searchInput) {
        searchInput.addEventListener('input', (event) => {
            clearTimeout(debounceTimeout);
            debounceTimeout = setTimeout(() => {
                const query = event.target.value.trim().toLowerCase();
                let anyMatch = false;
                
                tablesContainer.forEach(table => {
                    const categoryHeader = table.querySelector('.data-category h5');
                    const category = categoryHeader ? categoryHeader.textContent.toLowerCase() : '';
                    const rows = table.querySelectorAll('tbody tr');
                    let tableHasMatch = false;
                    
                    rows.forEach(row => {
                        const routeNameCell = row.querySelector('td:first-child');
                        const routeName = routeNameCell ? routeNameCell.textContent.toLowerCase() : '';
                        const match = routeName.includes(query) || category.includes(query);
                        row.style.display = match ? '' : 'none';
                        if (match) tableHasMatch = true;
                    });
                    
                    table.style.display = tableHasMatch || query === '' ? '' : 'none';
                    if (tableHasMatch) anyMatch = true;
                });
                
                noResults.style.display = anyMatch || query === '' ? 'none' : 'block';
            }, 300);
        });

        searchInput.addEventListener('focus', () => {
            searchInput.parentElement.classList.add('focused');
        });

        searchInput.addEventListener('blur', () => {
            searchInput.parentElement.classList.remove('focused');
        });
    }

    if (modalRefs.closeBtn) {
        modalRefs.closeBtn.addEventListener('click', hideModal);
    }
    modal.addEventListener('click', (e) => {
        if (e.target === modal) hideModal();
    });

    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && modal.style.display === 'flex') {
            hideModal();
        }
    });
});
